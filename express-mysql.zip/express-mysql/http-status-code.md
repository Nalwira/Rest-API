# HTTP Status Code

**Successful Response (2xx)**

- 200 OK (GET, PATCH)

- 201 Created (POST, PUT)

**Client Error Responses (4xx)**

- 400 Bad Request

- 401 Unauthorized

- 403 Forbidden

- 404 Not Found

- 405 Method Not Allowed

**Server error responses (5xx)**

- 500 Internal Server Error